class Atom {
  constructor(x, y, t) {
    this.x = x;
    this.y = y;
    this.w = 30;
    this.h = 30;
    this.dragging = false;
    this.text = t;
    this.atomAdded = false;
    this.count = 0;
  }
  showAtom() {

    if (this.dragging) {
      this.x = mouseX;
      this.y = mouseY;
    }
    ellipse(this.x, this.y, this.w * 2, this.h * 2);
    text(this.text, this.x, this.y);
  }
  pressed(ElX) {

    if (this.x - this.w < mouseX && mouseX < this.x + this.w && this.y - this.h < mouseY && mouseY < this.y + this.h) {
      this.dragging = true;
    }

  }
  notPressed() {
    this.dragging = false;
  }
  reset(x, y) {
    this.x = x;
    this.y = y;
    
    
  }
  drop(x, y) {
    if (dist(this.x, this.y, 470, 105)<75) {
      if(this.count<3){
      this.count++;
      }
      
      this.reset(x, y);
      this.atomAdded = true;
      
    }
    
  }
  
 structure(t, x, y) {
   if (this.atomAdded) {
     for (let i = 0; i < 3; i++) {  
       if (this.count > i) {
         ellipse(x + (30) * i, y, 30, 30);
         text(t, x+(30)*i, y)
       }
     }
   }
 }
 undo(){
   if(this.count>0)
   this.count--
 }
  showName(name){
    if(dist(this.x+10, this.y+10, mouseX, mouseY)<=30 && pressed === false){
      textSize(20)
      text(name, this.x, this.y+42)}
  }
}