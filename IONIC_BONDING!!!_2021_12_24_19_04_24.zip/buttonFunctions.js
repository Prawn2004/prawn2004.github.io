function start() {
  started = true;
  let undo1 = document.getElementById("UNDO1");
  undo1.style.display = "block";
  let undo2 = document.getElementById("UNDO2");
  undo2.style.display = "block";
  let toggle = document.getElementById("toggle");
  toggle.style.display = "block";
  let button = document.getElementById("button");
  button.style.display = "block";
}

function submit() {
  if (document.getElementById("button").innerHTML === "SUBMIT") {
    showResult();
  } else {
    moveOn();
  }
}

function info() {
  var x = document.getElementById("popup");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}

function showExplanation() {
  if(submitted){
  let totcharge1 = charge1 * amount1;
  let totcharge2 = charge2 * amount2;
  let x = document.getElementById("description");
  if(tries<tryCount){
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
  alert.style.display = "none";
  document.getElementById("description").innerHTML =
    "Since " + name1 + " has a charge of " + charge1 + ", and " + "there are " + amount1 + " " + name1 + " atoms, that gives us a total charge of " + charge1 + " x " + amount1 + " = " + totcharge1 + ". Also, since " + name2 + " has a charge of " + charge2 + ", and " + "there are " + amount2 + " " + name2 + " atoms, that gives us a total charge of " + charge2 + " x " + amount2 + " = " + totcharge2 + ". When you add both of these total charges, you get " + totcharge1 + " + " + totcharge2 + " = 0."
}
  }
}