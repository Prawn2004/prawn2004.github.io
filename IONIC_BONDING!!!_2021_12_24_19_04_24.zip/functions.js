function showWhereToDrop(){
  ellipse(465, 95, 150, 150);
    fill(75, 75, 75)
    textSize(25)
    text("DRAG AND\nDROP HERE", 465, 95);
}

function determineSolution(){
 
    
      if (charge1 === -3 && charge2 === 2) {
        amount1 = 2;
        amount2 = 3;
        structure1(type2, type1, 3, 2);
      } else
      if (charge1 === -2 && charge2 === 3) {
        amount1 = 3;
        amount2 = 2;
        structure1(type1, type2, 3, 2);
      } else
      if (charge1 === -1 && charge2 === 3) {
        amount1 = 3;
        amount2 = 1;
        structure2(type1, type2);
      } else
      if (charge1 === -3 && charge2 === 1) {
        amount1 = 1;
        amount2 = 3;
        structure2(type2, type1);
      } else
      if (abs(charge1) === charge2) {
        amount1 = 1;
        amount2 = 1;
        structure1(type1, type2, 1, 1);
      } else
      if (charge1 === -1 && charge2 === 2) {
        amount1 = 2;
        amount2 = 1;
        structure1(type1, type2, 2, 1);
      } else
      if (charge1 === -2 && charge2 === 1) {
        amount1 = 1;
        amount1 = 2;
        structure1(type2, type1, 2, 1);
      }

    
}

function structure1(a, b, row1, row2) {
  for (let i = 0; i < row1; i++) {
    ellipse(240 + 60 * i, 300, 50, 50);
    text(a, 240 + 60 * i, 300);
  }
  for (let i = 0; i < row2; i++) {
    ellipse(270 + 60 * i, 340, 50, 50)
    text(b, 270 + 60 * i, 340);
  }
}

function structure2(a, b) {
  for (let i = 0; i < 2; i++) {
    ellipse(270 + 60 * i, 260, 50, 50);
    text(a, 270 + 60 * i, 260);
  }
  ellipse(300, 350, 50, 50)
  text(a, 300, 350)
  ellipse(300, 300, 50, 50)
  text(b, 300, 300);
}



function showResult(){
  tries += 1;
    if(tries<tryCount){
    alert.style.display = "block";
    }
    let why = document.getElementById("expButton");
    why.style.display = "block";

    let charge = charge1 * el1.count + charge2 * el2.count;
    if (charge1 + charge2 === 0 && charge === 0) {
      if (el1.count > 1) {
        alert.innerHTML = "Unnecessary extra ion pairs"
      } else if(el1.count === 1){
        alert.innerHTML = "WELL DONE";
        win = true;
        score +=1;
      }
    }
    
    if (charge === 0 && el1.count > 0 && charge1 + charge2 !== 0) {
      alert.innerHTML = "WELL DONE";
      win = true;
      score +=1;
    }
    
    if (el1.count === 0 && el2.count === 0) {
      alert.innerHTML = "You forgot to make a molecule!"
    }
    
    else if (charge !== 0) {
      alert.innerHTML = "NOT QUITE - Total Charge = " + charge
    } //(charges not balanced)

    submitted = true;
    document.getElementById("button").innerHTML = "NEXT";
  popup.style.display = "none";
}

function moveOn(){
  if(tries<tryCount){  
 NM = Math.floor(Math.random() * (El1.type.length - 1));
 M = Math.floor(Math.random() * (El2.type.length - 1));


 charge1 = El1.charge[NM];
 charge2 = El2.charge[M];
 
 type1 = El1.type[NM]
 type2 = El2.type[M]

 name1 = El1.name[NM];
 name2 = El2.name[M];
    bg = 1;
    if(tries === tryCount){
      tries = 0;
    }
submitted = false;
win = false;
    document.getElementById("button").innerHTML = "SUBMIT"
    alert.style.display = "none"
    explanation.style.display = "none";
    popup.style.display = "none";
    nextLevel();
}else{window.location.reload();}

}

function startGame(){
  if (o > 0) o -= 0.01;
    if (bg > 0) bg -= 0.01;
    
    startbtn.style.opacity = o;
    title.style.opacity = o;
    if (startbtn.style.opacity < 0.01) {
      startbtn.style.display = "none";
    }
    // framesPassed+=1;
    // if(frameCount % 70 == 0 && timer > 0) timer--;
    background(0, 0, 80 * abs(bg - 1));

    push();

    fill(90, 90, 90);
    textSize(40);
    text(type1 + ":" + el1.count, 75, 480);
    text(type2 + ":" + el2.count, 200, 480);
    text(score + "/" + tries, 540, 565);
}