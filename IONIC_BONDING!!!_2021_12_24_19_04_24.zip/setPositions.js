function setPositions(){
  select("#UNDO1").position(160 + cx, 49 + cy);
  select("#UNDO2").position(160 + cx, 139 + cy);
  select("#toggle").position(10 + cx, 555 + cy);
  select("#button").position(410 + cx, 492 + cy);
  select("#expButton").position(410 + cx, 230 + cy);
  select("#title").position(cx, 200 + cy);
  select("#message").position(cx, 400 + cy);
  select("#startBTN").position(cx + 160, cy + 370);
  select("#popup").position(cx + 50, cy + 285);
  select("#description").position(cx + 410, cy + 275);
}