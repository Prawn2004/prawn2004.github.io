let El1 = {
  type: ["Cl", "I", "Br", "F", "N", "O", "P", "S", "Se"],
  name: [
    "Chlorine", "Iodine", "Bromine", "Flourine", "Nitrogen", "Oxygen", "Phophorus", "Sulfur", "Selenium",
  ],
  charge: [-1, -1, -1, -1, -3, -2, -3, -2, -2],
}; //Element 1
let NM = Math.floor(Math.random() * (El1.type.length - 1));
let El2 = {
  type: ["Na", "Al", "Ga", "In", "Tl", "Be", "Mg", "Ca", "Sr", "Ba", "Ra", "Li", "K", "Rb", "Cs", "Fr",
  ],
  name: ["Sodium", "Aluminum", "Gallium", "Indium", "Thallium", "Beryllium", "Magnesium", "Calcium", "Strontium", "Barium", "Radium", "Lithium", "Potassium", "Rubidium", "Caesium", "Francium",
  ],
  charge: [+1, +3, +3, +3, +3, +2, +2, +2, +2, +2, +2, +1, +1, +1, +1, +1],
}; //Element 2
let M = Math.floor(Math.random() * (El2.type.length - 1));

// let a = 3; //how many atoms of each element on screen
let charge1 = El1.charge[NM];
let charge2 = El2.charge[M];
let charge;
let type1 = El1.type[NM];
let type2 = El2.type[M];
let amount1;
let amount2;
let name1 = El1.name[NM];
let name2 = El2.name[M];
let started = false;
let cx = window.innerWidth / 2 - 300;
// if(window.innerWidth<850){
//   cx = 0;
// }
let cy = window.innerHeight / 2 - 300;
let o = 1;
let bg = 1;
let el1;
let el2;
let fps = 60;
let tryCount = 20;
function nextLevel() {
  el1 = new Atom(90, 50, type1);
  el2 = new Atom(90, 140, type2);
}
let tries = 0;
let startbtn = document.getElementById("startBTN");
    let title = document.getElementById("title");
function setup() {
  let canvas = createCanvas(600, 600);
  // window.onresize = function(){
  // canvas.height = window.outerHeight;
  // canvas.width = window.outerWidth;
  // }
  background(0);
  canvas.position(cx, cy);
  //Create instance of Atom for each element:
  nextLevel();
  setPositions();
}

function draw() {
  textAlign(CENTER, CENTER);
  textFont("Comic Sans MS");
  textStyle(BOLD);
  frameRate(fps);
  if (started) {
    startGame();

    if (tries === tryCount) {
      text("Game Over", 300, 300);
      textSize(30);
      text("score: " + score + "/" + tries, 300, 350);
    }

    showWhereToDrop();

    el1.showName(name1);
    el2.showName(name2);

    pop();

    el1.showAtom();
    el2.showAtom();

    if (submitted && tries < tryCount) {
      determineSolution();
    }

    el1.structure(type1, 45, 525);
    el2.structure(type2, 170, 525);
  }

  if (tries === tryCount) {
    document.getElementById("expButton").style.display = "none";
  }
}

let pressed = false;
function mousePressed() {
  el1.pressed();
  el2.pressed();
  pressed = true;
}
//When mouse is released call Atom.notPressed function:

function mouseReleased() {
  pressed = false;
  el1.notPressed();
  el2.notPressed();
  el1.drop(90, 50);
  el2.drop(90, 140);
}

let alert = document.getElementById("message");
let explanation = document.getElementById("description")
let popUp = document.getElementById("popup")
let submitted = false;
let win = false;
let score = 0;


